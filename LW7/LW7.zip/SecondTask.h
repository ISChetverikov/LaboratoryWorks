#pragma once

int CreateSecondFile(char * filename, int stringsCount);
int DoSecondTask(char * inputFilename, char * outputFilename);