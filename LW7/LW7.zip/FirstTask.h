#define DOUBLE_ARRAY_BUFFER 1024

#define DOUBLE_RAND_LENGTH 2.0
#define DOUBLE_RAND_MIN -1.0

int CreateFirstFile(char * filename, int numbersCount);
int DoFirstTask(char * filename, int N, double * result);